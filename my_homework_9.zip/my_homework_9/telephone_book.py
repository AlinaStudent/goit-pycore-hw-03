from collections import UserDict
import re

class Field:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)

class Name(Field):
    def __init__(self, value):
        if not value.isalpha():
            raise ValueError("Имя должно содержать только буквы")
        super().__init__(value)

class Phone(Field):
    def __init__(self, value):
        if not re.fullmatch(r'\d{10}', value):
            raise ValueError("Телефон должен быть из 10 цифр")
        super().__init__(value)

class Record:
    def __init__(self, name):
        self.name = Name(name)
        self.phones = []

    def add_phone(self, phone):
        self.phones.append(Phone(phone))

    def remove_phone(self, phone):
        self.phones = [p for p in self.phones if p.value != phone]

    def edit_phone(self, old, new):
        for i, p in enumerate(self.phones):
            if p.value == old:
                self.phones[i] = Phone(new)
                return
        raise ValueError("Старый номер не найден")

    def find_phone(self, phone):
        for p in self.phones:
            if p.value == phone:
                return p
        return None

    def __str__(self):
        phones = ', '.join(p.value for p in self.phones) or "нет телефонов"
        return f"{self.name.value}: {phones}"

class AddressBook(UserDict):
    def add_record(self, record):
        self.data[record.name.value] = record

    def find(self, name):
        return self.data.get(name)

    def delete(self, name):
        if name in self.data:
            del self.data[name]
            return True
        return False

# Пример использования
if __name__ == "__main__":
    book = AddressBook()

    alina = Record("Alina")
    alina.add_phone("1234567890")
    alina.add_phone("0987654321")
    book.add_record(alina)

    print(book.find("Alina"))      # Alina: 1234567890, 0987654321
    alina.edit_phone("0987654321", "1112223333")
    print(alina.find_phone("1112223333"))  # 1112223333
    book.delete("Alina")