

import re                                         
from collections import UserDict                  
from datetime import datetime, timedelta         

# ----------- Поля ------------

class Field:                                     
    def __init__(self, value):
        self.value = value

class Name(Field):                               
    def __init__(self, value):
        if not value.isalpha():
            raise ValueError("Им'я має містити тільки літери")
        super().__init__(value)

class Phone(Field):                              
    def __init__(self, value):
        if not re.fullmatch(r'\d{10}', value):
            raise ValueError("Телефон має складатися з 10 цифр")
        super().__init__(value)

class Birthday(Field):                           # добавлено
    def __init__(self, value):
        try:
            date = datetime.strptime(value, "%d.%m.%Y").date()
        except ValueError:
            raise ValueError("Невірний формат. Використовуйте DD.MM.YYYY")
        super().__init__(date)

# ----------- Контакт ------------

class Record:                                    # було та доповнен
    def __init__(self, name: str):
        self.name = Name(name)                    
        self.phones: list[Phone] = []             
        self.birthday: Birthday | None = None     # добавлено

    def add_phone(self, phone: str):              
        self.phones.append(Phone(phone))

    def change_phone(self, old: str, new: str):   # аналог edit_phone — було
        for idx, p in enumerate(self.phones):
            if p.value == old:
                self.phones[idx] = Phone(new)
                return
        raise ValueError("Старий номер не знайдено")

    def remove_phone(self, phone: str):           
        self.phones = [p for p in self.phones if p.value != phone]

    def find_phone(self, phone: str):             
        for p in self.phones:
            if p.value == phone:
                return p
        return None

    def add_birthday(self, bday: str):            # добавлено
        self.birthday = Birthday(bday)

    def days_to_birthday(self) -> int | None:     # добавлено
        if not self.birthday:
            return None
        today = datetime.today().date()
        b = self.birthday.value.replace(year=today.year)
        if b < today:
            b = b.replace(year=today.year + 1)
        return (b - today).days

    def __str__(self):                           # було + расширен
        phones = ", ".join(p.value for p in self.phones) or "немає телефонів"
        bd = (
            self.birthday.value.strftime("%d.%m.%Y")
            if self.birthday
            else "немає дати народження"         # добавлено текст
        )
        return f"{self.name.value}: {phones} | Birthday: {bd}"

# ----------- Адресна книга ------------

class AddressBook(UserDict):                     # було + дополнен
    def add_record(self, rec: Record):            
        self.data[rec.name.value] = rec

    def find(self, name: str):                    
        return self.data.get(name)

    def delete(self, name: str) -> bool:          
        if name in self.data:
            del self.data[name]
            return True
        return False

    def get_upcoming_birthdays(self) -> list[str]:# добавлено
        today = datetime.today().date()
        result = []
        for rec in self.data.values():
            days = rec.days_to_birthday()
            if days is not None and 0 <= days <= 7:
                bday_date = (today + timedelta(days=days)).strftime("%d.%m.%Y")
                result.append(f"{rec.name.value} — {bday_date}")
        return result

# ----------- Декоратор обробки помилок ------------

def input_error(func):                           
    def wrapper(args, book):
        try:
            return func(args, book)
        except (ValueError, IndexError) as e:
            return f"Error: {e}"
    return wrapper

# ----------- Функції-команди ------------

@input_error                                  
def add_contact(args, book: AddressBook):     
    name, phone = args
    rec = book.find(name)
    if not rec:
        rec = Record(name)
        book.add_record(rec)
        msg = "Contact added."
    else:
        msg = "Contact updated."
    rec.add_phone(phone)
    return msg

@input_error
def change_phone(args, book: AddressBook):    
    name, old, new = args
    rec = book.find(name)
    if not rec:
        raise ValueError("Контакт не знайдено")
    rec.change_phone(old, new)
    return "Phone changed."

@input_error
def show_phone(args, book: AddressBook):      
    name = args[0]
    rec = book.find(name)
    if not rec:
        raise ValueError("Контакт не знайдено")
    return ", ".join(p.value for p in rec.phones) or "немає телефонів"

def show_all(args, book: AddressBook):        
    if not book.data:
        return "Адресна книга порожня"
    return "\n".join(str(rec) for rec in book.data.values())

@input_error
def add_birthday(args, book: AddressBook):    # добавлено
    name, bday = args
    rec = book.find(name)
    if not rec:
        raise ValueError("Контакт не знайдено")
    rec.add_birthday(bday)
    return "Birthday added."

@input_error
def show_birthday(args, book: AddressBook):   # добавлено
    name = args[0]
    rec = book.find(name)
    if not rec:
        raise ValueError("Контакт не знайдено")
    if not rec.birthday:
        return "Birthday not set."
    return rec.birthday.value.strftime("%d.%m.%Y")

def birthdays(args, book: AddressBook):       # добавлено
    upcoming = book.get_upcoming_birthdays()
    return "\n".join(upcoming) if upcoming else "No upcoming birthdays."

# ----------- Парсинг вводу ------------

def parse_input(line: str) -> tuple[str, list[str]]:  # було
    parts = line.strip().split()
    cmd = parts[0].lower()
    return cmd, parts[1:]

# ----------- Головна функція ------------

def main():                                       
    book = AddressBook()
    print("Welcome to the assistant bot!")
    while True:
        line = input("Enter command: ")
        cmd, args = parse_input(line)

        if cmd in ("close", "exit"):
            print("Good bye!")
            break
        elif cmd == "hello":
            print("How can I help you?")
        elif cmd == "add":
            print(add_contact(args, book))
        elif cmd == "change":
            print(change_phone(args, book))
        elif cmd == "phone":
            print(show_phone(args, book))
        elif cmd == "all":
            print(show_all(args, book))
        elif cmd == "add-birthday":               # добавлено
            print(add_birthday(args, book))
        elif cmd == "show-birthday":              # добавлено
            print(show_birthday(args, book))
        elif cmd == "birthdays":                  # добавлено
            print(birthdays(args, book))
        else:
            print("Invalid command.")

if __name__ == "__main__":                      
    main()


