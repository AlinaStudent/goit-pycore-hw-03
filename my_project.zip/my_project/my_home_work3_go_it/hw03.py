import sys
from pathlib import Path
from colorama import init, Fore, Style

init(autoreset=True)

def print_directory_structure(directory: Path, indent: str = ""):
    try:
        for item in sorted(directory.iterdir()):
            if item.is_dir():
                print(f"{indent}{Fore.BLUE}{item.name}/")
                print_directory_structure(item, indent + "    ")
            else:
                print(f"{indent}{Fore.GREEN}{item.name}")
    except PermissionError:
        print(f"{indent}{Fore.RED}Permission denied: {directory}")

def main():
    if len(sys.argv) != 2:
        print(f"{Fore.RED}Використання: python hw03.py <шлях_до_директорії>")
        sys.exit(1)

    directory_path = Path(sys.argv[1])

    if not directory_path.exists():
        print(f"{Fore.RED}Помилка: вказаний шлях не існує.")
        sys.exit(1)
    if not directory_path.is_dir():
        print(f"{Fore.RED}Помилка: вказаний шлях не є директорією.")
        sys.exit(1)

    print(f"{Fore.CYAN}Структура директорії '{directory_path.resolve()}':\n")
    print_directory_structure(directory_path)

if __name__ == "__main__":
    main()

    # шлях до директорії
python C:\PROJECTS\TRAINNINGS\my_project\my_home_work3_go_it\hw03.py C:\Users\alina\Pictures