# Словарь для хранения контактов
contacts = {}

def parse_input(user_input):
    """
    Разбивает введённую строку на команду и аргументы.
    Команда приводится к нижнему регистру.
    """
    parts = user_input.split()  # Разбиваем строку по пробелам
    if not parts:
        return "", []
    return parts[0].lower(), parts[1:]

def hello_handler():
    """
    Обрабатывает команду "hello".
    """
    return "How can I help you?"

def add_handler(args):
    """
    Обрабатывает команду "add username phone".
    Если передано ровно 2 аргумента, контакт добавляется.
    """
    if len(args) != 2:
        return "Invalid command."
    name, phone = args
    contacts[name] = phone
    return "Contact added."

def change_handler(args):
    """
    Обрабатывает команду "change username phone".
    Если контакт существует, меняет его номер.
    """
    if len(args) != 2:
        return "Invalid command."
    name, phone = args
    if name in contacts:
        contacts[name] = phone
        return "Contact updated."
    return "Contact not found."

def phone_handler(args):
    """
    Обрабатывает команду "phone username".
    Возвращает телефон, если контакт найден.
    """
    if len(args) != 1:
        return "Invalid command."
    name = args[0]
    return contacts.get(name, "Contact not found.")

def all_handler():
    """
    Обрабатывает команду "all".
    Возвращает список всех контактов или сообщение, если список пуст.
    """
    if not contacts:
        return "No contacts found."
    return "\n".join(f"{name}: {phone}" for name, phone in contacts.items())

def main():
    """
    Основная функция, которая:
      - Запускает бесконечный цикл ввода команд.
      - Выводит ответ пользователя.
      - Завершает работу при командах "exit" или "close".
    Все операции ввода/вывода происходят здесь.
    """
    print("Welcome to the assistant bot!")
    while True:
        user_input = input("Enter a command: ")
        command, args = parse_input(user_input)
        
        if command in ["exit", "close"]:
            print("Good bye!")
            break
        elif command == "hello":
            print(hello_handler())
        elif command == "add":
            print(add_handler(args))
        elif command == "change":
            print(change_handler(args))
        elif command == "phone":
            print(phone_handler(args))
        elif command == "all":
            print(all_handler())
        else:
            print("Invalid command.")

if __name__ == "__main__":
    main()