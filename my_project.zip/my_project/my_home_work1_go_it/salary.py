def create_salary_file(path):
    data = [
        "Alex Korp,3000\n",
        "Nikita Borisenko,2000\n",
        "Sitarama Raju,1000\n"
    ]
    try:
        with open(path, 'w', encoding='utf-8') as file:
            file.writelines(data)
        print(f" Файл успішно створено за шляхом: {path}")
    except Exception as e:
        print(f" Помилка при створенні файлу: {e}")

def total_salary(path):
    try:
        with open(path, 'r', encoding='utf-8') as file:
            salaries = []
            for line in file:
                try:
                    _, salary = line.strip().split(',')
                    salaries.append(float(salary))
                except ValueError:
                    continue

        if not salaries:
            return 0, 0

        total = sum(salaries)
        average = total / len(salaries)
        return total, average

    except FileNotFoundError:
        print(f"Файл за шляхом {path} не знайдено.")
        return 0, 0
    except Exception as e:
        print(f"Сталася помилка при обробці файлу: {e}")
        return 0, 0

#  Шлях до файлу (змініть на свій власний, якщо потрібно)
file_path = "C:/Users/Alina/Documents/salaries.txt"

# Створення файлу
create_salary_file(file_path)

# Аналіз файлу
total, average = total_salary(file_path)
print(f"Загальна сума заробітної плати: {total}, Середня заробітна плата: {average}")