def caching_fibonacci():
    cache = {}  # Словник для кешування вже обчислених значень

    def fibonacci(n):
        if n <= 0:
            return 0
        if n == 1:
            return 1
        if n in cache:  # Якщо значення вже є у кеші — повертаємо його
            return cache[n]
        
        # Рекурсивне обчислення і збереження у кеш
        cache[n] = fibonacci(n - 1) + fibonacci(n - 2)
        return cache[n]

    return fibonacci  # Повертаємо внутрішню функцію

fib = caching_fibonacci()

print(fib(10))  # Виведе: 55
print(fib(15))  # Виведе: 610
print(fib(30))  # Виведе: 832040