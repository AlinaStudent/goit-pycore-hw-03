def generator_numbers(text):
    for word in text.split():   # розбиває рядок на слова
        if word.replace('.', '', 1).isdigit(): # дозволяє визначити дійсне число 
            yield float(word) # повертає одне число за раз

def sum_profit(text, func): # додає всі знайдені числа
    return sum(func(text))


text = "Мій дохід: 250.5 з однієї справи і 300.55 з іншої"
print(sum_profit(text, generator_numbers))  

# Виведе: 551.05