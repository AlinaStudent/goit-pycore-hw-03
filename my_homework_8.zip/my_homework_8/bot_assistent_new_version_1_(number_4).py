#  Словник для зберігання контактів
contacts = {}

#  Декоратор для обробки помилок
def input_error(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyError:
            return "Contact not found."
        except ValueError:
            return "Give me name and phone please."
        except IndexError:
            return "Enter user name."
    return wrapper

#  Привітання
def hello_handler():
    return "How can I help you?"

#  Додати контакт
@input_error
def add_handler(args):
    if len(args) != 2:
        raise ValueError
    name, phone = args
    contacts[name] = phone
    return "Contact added."

#  Змінити контакт
@input_error
def change_handler(args):
    if len(args) != 2:
        raise ValueError
    name, phone = args
    if name not in contacts:
        raise KeyError
    contacts[name] = phone
    return "Contact updated."

#  Знайти телефон за ім’ям
@input_error
def phone_handler(args):
    if len(args) != 1:
        raise ValueError
    name = args[0]
    if name not in contacts:
        raise KeyError
    return contacts[name]

#  Всі контакти
@input_error
def all_handler():
    if not contacts:
        return "No contacts found."
    return "\n".join(f"{name}: {phone}" for name, phone in contacts.items())


def main():
    print("Assistant bot started. Type a command.")
    while True:
        parts = input("> ").split()
        if not parts:
            continue
        cmd, *args = parts
        if cmd in ("exit", "close"):
            print("Good bye!")
            break
        if cmd == "hello":
            print("How can I help you?")
            continue

        commands = {
            "add": add_contact,
            "change": change_contact,
            "phone": get_phone,
            "all": show_all
        }
        handler = commands.get(cmd, lambda a: "Invalid command.")
        print(handler(args))

if __name__ == "__main__":
    main()

